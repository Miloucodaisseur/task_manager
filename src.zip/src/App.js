import React from 'react';
import ToDoList from './toDoList'

class App extends React.Component {

	render() {
        return (
          <ToDoList />
        );
    }
}

export default App;